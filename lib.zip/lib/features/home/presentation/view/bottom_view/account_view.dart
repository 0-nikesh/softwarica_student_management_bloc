import 'package:flutter/material.dart';

class AccountView extends StatelessWidget {
  const AccountView({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Account View',
        style: TextStyle(fontSize: 30),
      ),
    );
  }
}
